/* package firstgames;

import firstgames.TicTacToeTests;

public class TicTacToeTests {

    public static void main (String [] args) {
        
        boolean ok = true; 

        TicTacToeTests ticTacToeTester = new TicTacToeTests();
        ok = ok && ticTacToeTester.testGetCurrentPlayer();
        ok = ok && ticTacToeTester.testExecuteAndIsValid();
    }
} */