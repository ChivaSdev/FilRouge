package firstgames;

import java.util.Array;
import java.util.ArrayList;

public class TicTacToe {

    private Player player1;

    private Player player2;

    private Player[][] gameTab;

    
    public TicTacToe(Player player1, Player player2) {
        this.player1 = player1;
        this.player2 = player2;
        this.currentPlayer = player1;
        this.gameTab = new Player[3][3];
    }
    
    public void execute(int move) {
        this.gameTab[(move/3)][(move%3)] = this.currentPlayer;
        if (this.currentPlayer == player1) {
            this.currentPlayer = player2; 
        } else {
            this.currentPlayer = player1;
        }
    }

    public boolean isValid(int move) {
        if (this.gameTab[(move/3)][(move%3)] == null) {
            return true;
        } else {
            return false; 
        }
    }

    public ArrayList<Integer> validMoves() {
        ArrayList<Integer> listMoves = new ArrayList<>();
        for (int i=0; i<this.gameTab.size(); i++) {
            for (int v=0; this.gameTab.size(); i++) {
                if (this.gameTab[i][v] == null) {
                    listMoves.add(3 * i + v);
                }
            }
        }
        return listMoves;
    }

    public boolean wins(Player player, int row, int column, int deltaRow, int deltaColumn) {
        return (this.gameTab[row][column] == player) && (this.gameTab[row + deltaRow][column + deltaColumn] == player) && (this.gameTab[row + 2*deltaRow][column + 2*deltaColumn] == player);
    }

    public Player getWinner() {
        for i 
    }
}

