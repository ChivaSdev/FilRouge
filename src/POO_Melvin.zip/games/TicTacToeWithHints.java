/* package games;

import java.util.ArrayList;
import players.Player;

public class TicTacToeWithHints extends TicTacToe {

    public TicTacToeWithHints(Player player1, Player player2) {
        super(player1, player2);
    }

    public ArrayList<Integer> hints() {
        
    }
} */